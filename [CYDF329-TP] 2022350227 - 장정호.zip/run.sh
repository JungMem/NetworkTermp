#!/bin/sh

sudo apt-get update

sudo apt-get install -y make

sudo apt-get install -y gcc

make
